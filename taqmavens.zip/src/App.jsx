import React from 'react';
import './App.css';
import sphere from './assets/Sphere.png';
import d1logo from './assets/d1logo.png';
import aicon from './assets/aicon.png';
export default function App() {
  function AvatarGroup({ users = ["anita", "mike", "jane"] }) {
    return (
      <div className=" text-center text-white">
        {/* Stats */}

        <p className=" text-[62px] leading-[56px]  font-semibold leading-[34px] bg-[linear-gradient(136deg,_rgba(255,178,102,1)_0%,_rgba(233,118,111,1)_49%,_rgba(192,67,80,1)_100%)] bg-clip-text text-transparent">
          12K
        </p>
        <p className="text-[18px] leading-[24px] mt-[10px] text-[#B2A1FD] mt-[2px]">
          after – $5/month
        </p>

        {/* Avatars */}
        <div className="mt-6 flex justify-center">
          {users.length === 0 ? null : (
            <div className="flex items-center">
              {users.map((user, index) => (
                <div
                  key={index}
                  className={`w-[56px] h-[56px] rounded-full bg-gray-500 ${index === 0 ? '' : '-ml-3'
                    } border-2 border-[#0E123D] flex items-center justify-center text-sm text-white`}
                >
                  {/* You can replace this div content with actual <img src={user.avatar}/> */}
                  IMG
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white w-full">
      <div className="bg-[#03061C] min-h-screen py-12 px-4 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-[262px_1fr_262px] gap-6 justify-items-center">

          {/* LEFT COLUMN */}
          <div className="flex flex-col gap-6 w-full min-w-[262px]">
            <div className="bgdiv flex flex-col h-[396px]  w-full">
              <div>
                <img
                  className="w-[54px] h-[44px]"
                  src={d1logo}
                  alt="d1logo"
                />

                <p className="text-[28px] mt-5 font-semibold leading-[34px] bg-gradient-to-r from-white to-[#AA9CFC] bg-clip-text text-transparent">
                  Effortless <br /> Prompt <br /> Perfection
                </p>
              </div>

              {/* Bottom Pricing Info */}
              <div className='mt-auto'>
                <p className="text-[18px] font-bold text-[#E6E3FF]">
                  14 days trial
                </p>
                <p className="text-[16px] text-[#ACA0E4] mt-[2px]">
                  after – $5/month
                </p>
              </div>
            </div>
            <div className="bgdiv h-[220px]  w-full">
              <AvatarGroup />
            </div>
            {/* /generate btn */}

            <div className="bgdiv h-[164px] w-full flex justify-center items-center">
              <span className="buttoncss relative flex items-center gap-2 w-[200px] h-[70px] rounded-full overflow-hidden text-white font-semibold backdrop-blur-md">
                {/* Radial Gradient Background */}
              
                {/* Inner glass effect layer (optional) */}
                <div className="absolute inset-0 z-10 rounded-full bg-white/10 shadow-[inset_0_0_8px_rgba(255,255,255,0.1)] pointer-events-none"></div>

                {/* Content */}
                <div className="relative z-20 flex items-center gap-2 px-4">
                  <img src={aicon} alt="aicon" className="w-5 h-5" />
                  <span className='text-[20px] lending-[24px] font-normal'>Generate</span>
                </div>
              </span>
            </div>

            {/* generate btn */}
          </div>

          {/* CENTER COLUMN */}
          <div className="relative flex flex-col items-center gap-6 xs:min-w-[262px] min-w-[262px] sm:min-w-[262px] w-full px-2">
            {/* Top Box */}
            <div className="innergrid1 min-h-[396px] w-full rounded-xl">1</div>

            {/* Sphere - centered */}
            {/* <div className="relative h-[0px]"> */}
            <img
              src={sphere}
              alt="sphere"
              className="absolute sphere min-w-[188px] min-h-[188px] object-contain"
            />
            {/* </div> */}

            {/* Bottom Boxes */}
            <div className="flex  sm:flex-row gap-5 w-full ">
              <div className="innergrid2 flex-1 w-full min-h-[412px] rounded-xl">2</div>
              <div className="innergrid3 flex-1 w-full min-h-[412px] rounded-xl">3</div>
            </div>
          </div>

          {/* RIGHT COLUMN */}
          <div className="flex flex-col gap-6 w-full min-w-[262px]">
            <div className="bgdiv h-[157px] w-full flex items-center justify-center">3</div>
            <div className="bgdiv h-[211px] w-full flex items-center justify-center">4</div>
            <div className="bgdiv h-[412px] w-full flex items-center justify-center">6</div>
          </div>

        </div>
      </div>
    </div>
  );
}
